#include "FutureInfor.h"


CFutureInfor::CFutureInfor(void)
{
}


CFutureInfor::~CFutureInfor(void)
{
}
